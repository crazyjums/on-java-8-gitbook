<div align="center">
    <img src="https://raw.githubusercontent.com/LingCoder/OnJava8/master/docs/images/cover.jpg" alt="cover" width="100%"/>
</div>

<div style="page-break-after: always;"></div>

<center style="165px 0px 0px">
<p style="font-size: 6em;font-weight: bold;text-align: center"> On Java 8 </p>
</center>

<center style="165px 0px 0px">
<p style="font-size: 2em;font-weight: bold;text-align: center">Bruce Eckel</p>

</center>

<center> MindView LLC </center>


<center>2017</center>


<center>©MindView LLC 版权所有</center>





<div style="page-break-after: always;"></div>




# On Java 8



**版权©2017**


**作者 Bruce Eckel, President, MindView LLC.**


**版本号：7**


**ISBN 978-0-9818725-2-0**


**原书可在该网站购买  [www.OnJava8.com](http://www.OnJava8.com)** 




本书出版自美国，版权所有，翻版必究。未经授权不得非法存储在检索系统中，或以电子，机械，影印，录制任何形式传输等。制造商和销售商使用商标用来区分其产品标识。如果这些名称出现在这本书中，并且出版商知道商标要求，则这些名称已经用大写字母或所有大写字母打印。

Java 是甲骨文公司（Oracle. Inc.）的商标。Windows 95，Windows NT，Windows 2000，Windows XP，Windows 7，Windows 8 和 Windows 10 是微软公司（Microsoft Corporation）的商标。
此处提及的所有其他产品名称和公司名称均为其各自所有者的财产。作者和出版商在编写本书时已经仔细校对过，但不作任何明示或暗示的保证，对错误或遗漏不承担任何责任。对于因使用此处包含的信息或程序而产生的偶然或间接损失，我们不承担任何责任。

这本书是以平板电脑和计算机为载体的电子书，非传统纸质版书籍。 
故所有布局和格式设计旨在优化您在各种电子书阅读平台和系统上的观看体验。
封面由 Daniel Will-Harris 设计，[www.Will-Harris.com](http://www.Will-Harris.com)。

<div style="page-break-after: always;"></div>